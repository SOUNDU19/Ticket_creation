import pandas as pd
from sklearn.linear_model import LinearRegression
import pickle

# Load dataset
df = pd.read_csv("manufacturing_dataset_1000_samples.csv")

# Remove missing rows
df = df.dropna()

# Input features (ALL 13)
X = df[[
    'Injection_Temperature',
    'Injection_Pressure',
    'Cycle_Time',
    'Cooling_Time',
    'Material_Viscosity',
    'Ambient_Temperature',
    'Machine_Age',
    'Operator_Experience',
    'Maintenance_Hours',
    'Temperature_Pressure_Ratio',
    'Total_Cycle_Time',
    'Efficiency_Score',
    'Machine_Utilization'
]]

# Target
y = df['Parts_Per_Hour']

# Train
model = LinearRegression()
model.fit(X, y)

# Save model
pickle.dump(model, open("model.pkl", "wb"))

print("Model trained successfully!")
