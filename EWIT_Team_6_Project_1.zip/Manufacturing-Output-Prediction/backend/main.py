from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import pickle
import numpy as np

app = FastAPI()

# ✅ ADD CORS (VERY IMPORTANT)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load model
model = pickle.load(open("model.pkl", "rb"))

class MachineInput(BaseModel):
    Injection_Temperature: float
    Injection_Pressure: float
    Cycle_Time: float
    Cooling_Time: float
    Material_Viscosity: float
    Ambient_Temperature: float
    Machine_Age: float
    Operator_Experience: float
    Maintenance_Hours: float
    Temperature_Pressure_Ratio: float
    Total_Cycle_Time: float
    Efficiency_Score: float
    Machine_Utilization: float

@app.get("/")
def home():
    return {"message": "Manufacturing Prediction API Running"}

@app.post("/predict")
def predict(data: MachineInput):

    values = np.array([[
        data.Injection_Temperature,
        data.Injection_Pressure,
        data.Cycle_Time,
        data.Cooling_Time,
        data.Material_Viscosity,
        data.Ambient_Temperature,
        data.Machine_Age,
        data.Operator_Experience,
        data.Maintenance_Hours,
        data.Temperature_Pressure_Ratio,
        data.Total_Cycle_Time,
        data.Efficiency_Score,
        data.Machine_Utilization
    ]])

    prediction = model.predict(values)

    return {
        "Predicted_Parts_Per_Hour": float(prediction[0])
    }